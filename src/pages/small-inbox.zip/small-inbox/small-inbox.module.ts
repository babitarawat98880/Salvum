import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SmallInboxPageRoutingModule } from './small-inbox-routing.module';

import { SmallInboxPage } from './small-inbox.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SmallInboxPageRoutingModule
  ],
  declarations: [SmallInboxPage]
})
export class SmallInboxPageModule {}
